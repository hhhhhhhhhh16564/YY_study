//
//  Model.h
//  archiviewroot
//
//  Created by 周磊 on 16/6/1.
//  Copyright © 2016年 zhl. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Model : NSObject

@property(nonatomic, strong) NSString *name;
@property(nonatomic, strong) NSString *detailname;
@end
