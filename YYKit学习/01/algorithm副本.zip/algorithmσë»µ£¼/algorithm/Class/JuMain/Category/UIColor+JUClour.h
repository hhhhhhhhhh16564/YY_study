//
//  UIColor+JUClour.h
//  七月算法_iPad
//
//  Created by pro on 16/5/19.
//  Copyright © 2016年 zhl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (JUClour)
+ (UIColor *)colorWithHexString:(NSString *)color alpha:(CGFloat)alpha;
@end
