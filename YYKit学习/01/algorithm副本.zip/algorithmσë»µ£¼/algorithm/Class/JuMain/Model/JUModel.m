//
//  JUModel.m
//  七月算法_iPad
//
//  Created by 周磊 on 16/5/17.
//  Copyright © 2016年 zhl. All rights reserved.
//

#import "JUModel.h"

@implementation JUModel

//一句话将所有的子文件全部归档反归档(MJExtension)
MJCodingImplementation

//-(NSMutableArray *)properArray{
//    
//    NSMutableArray *array = [NSMutableArray array];;
//    
//    unsigned int ivarCount = 0;
//    //获取实例变量数组
//    Ivar *invarArray = class_copyIvarList([self class], &ivarCount);
//    
//    for (int i = 0; i < ivarCount; i++) {
//        Ivar var = invarArray[i];
//        
//        //获得属性名字  属性类型
////        NSLog(@"%s, %s", ivar_getName(var), ivar_getTypeEncoding(var));
//        
//        const char *name = ivar_getName(var);
//        
//        NSString *propertystring = [[NSString alloc]initWithUTF8String:name];
//        
//        [array addObject:propertystring];
//        
//        
//    }
//    
//    free(invarArray);
//    
//
//    return array;
//    
//    
//}
//
//+(NSString *)description
//{
//    
//
//    
//    
//}









@end
