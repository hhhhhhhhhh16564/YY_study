//
//  JUModel.h
//  七月算法_iPad
//
//  Created by 周磊 on 16/5/17.
//  Copyright © 2016年 zhl. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JUModel : NSObject<NSCoding>


@end
